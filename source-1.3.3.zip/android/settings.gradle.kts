pluginManagement {
	val flutterSdkPath = run {
		val properties = java.util.Properties()
		file("local.properties").inputStream().use { properties.load(it) }
		val flutterSdkPath = properties.getProperty("flutter.sdk")
		require(flutterSdkPath != null) { "flutter.sdk not set in local.properties" }
		flutterSdkPath
	}

	includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

	repositories {
		maven("https://maven.aliyun.com/repository/public")
		maven("https://maven.aliyun.com/repository/google")
		google()
		mavenCentral()
		gradlePluginPortal()
	}
}

plugins {
	id("dev.flutter.flutter-plugin-loader") version "1.0.0"
	id("com.android.application") version "9.1.1" apply false
	id("org.jetbrains.kotlin.android") version "2.4.0" apply false
}

include(":app")
